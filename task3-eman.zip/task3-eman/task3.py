# Eman Asfour 1200206 
# The Third Task 
# Bring in required libraries
import pandas as pd # To manipulate and analyze data
import numpy as np   # In relation to numerical operations
import os  # In order to communicate with the operating system

def read_input_files(allocation_path, request_path, available_path): # the function to read  input file
    # read pandas DataFrames by reading CSV files.
    allocation_df_Eman = pd.read_csv(allocation_path, index_col=0)
    request_df_E = pd.read_csv(request_path, index_col=0)
    available_df_Eman = pd.read_csv(available_path, header=None, skiprows=1)

    # Take the first row's available vector and extract it.
    available_vector_Eman = available_df_Eman.iloc[0, :].to_numpy(dtype=int)

    # Pandas DataFrames to NumPy array conversion
    allocation_matrix_E = allocation_df_Eman.to_numpy(dtype=int)
    request_matrix_E = request_df_E.to_numpy(dtype=int)

    # Check the dimensions.
    n_processes, m_resources = allocation_matrix_E.shape
    assert request_matrix_E.shape == (n_processes, m_resources)
    assert available_vector_Eman.shape == (m_resources,)

    # Get process names from the index of the request DataFrame
    process_names_E = request_df_E.index

    return allocation_matrix_E, request_matrix_E, available_vector_Eman, n_processes, m_resources, process_names_E

# Function to check if the system is in a deadlocked state
def is_deadlocked(allocation_E, request_E, available_Eman):
    work_E = available_Eman.copy()
    finish_E = np.zeros(len(allocation_E), dtype=bool)

    while True:
        found = False
        for i in range(len(allocation_E)):
            if not finish_E[i] and np.all(request_E[i, :] <= work_E):
                work_E += allocation_E[i, :]
                finish_E[i] = True
                found = True

        if not found:
            break

    return not np.all(finish_E)

# A feature that determines if the system is safe
def is_safe_state(allocation_E, request_E, available_Eman):
    work_E = available_Eman.copy()
    finish_E = np.zeros(len(allocation_E), dtype=bool)

    while True:
        found = False
        for i in range(len(allocation_E)):
            if not finish_E[i] and np.all(request_E[i, :] <= work_E):
                work_E += allocation_E[i, :]
                finish_E[i] = True
                found = True

        if not found:
            break

    return np.all(finish_E)

# Example usage
allocation_matrix_E, request_matrix_E, available_vector_Eman, n_processes_E, m_resources_E, process_names_E = read_input_files(
    '/home/codebind/Desktop/task3/Allocation.csv',
    '/home/codebind/Desktop/task3/Request.csv',
    '/home/codebind/Desktop/task3/Available.csv'
)

# Check if the system is in a safe state
if is_safe_state(allocation_matrix_E, request_matrix_E, available_vector_Eman):
    print("System is in a safe state.")
    # Optionally, print the process values
    for i in range(n_processes_E):
        print(f"Process {process_names_E[i]} values:", allocation_matrix_E[i, :])
else:
    print("System is not in a safe state. Deadlock may occur.")

# Check for deadlock
if is_deadlocked(allocation_matrix_E, request_matrix_E, available_vector_Eman):
    print("Deadlock detected.")
    # List processes that are deadlocked
    deadlocked_processes_E = [process_names_E[i] for i in range(n_processes_E) if not np.all(request_matrix_E[i, :] <= available_vector_Eman)]
    print("Deadlocked processes:", deadlocked_processes_E)
else:
    print("No deadlock detected.")
