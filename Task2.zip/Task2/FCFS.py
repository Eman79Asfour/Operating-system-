#Eman  Asfour 1200206
#1- First Come First Served
def calculate_times(processes):
    current_time = 0

    for process in processes:
        process['waitingTime'] = current_time
        current_time += process['burstTime']
        process['turnaroundTime'] = current_time


def print_gantt_chart(processes):
    print("Gantt Chart:")
    for process in processes:
        print(process['waitingTime'], end=" ")

        # Check if there is a comeback time for the process
        if process['comebackTime'] > 0:
            print("\nP" + str(process['processID']))
            print(process['comebackTime'], end=" ")

        print("P" + str(process['processID']), end=" ")

    print("\nF")


def simulate_cpu(processes, time_limit):
    # Sort processes based on arrival time
    processes.sort(key=lambda x: x['arrivalTime'])
    current_time = processes[0]['arrivalTime']

    while current_time <= time_limit:
        for process in processes:
            if process['arrivalTime'] <= current_time and process['remainingTime'] > 0:
                process['remainingTime'] -= 1
                process['turnaroundTime'] += 1
                current_time += 1

            # Check and handle the comeback time
            if process['comebackTime'] > 0 and process['comebackTime'] == current_time:
                process['waitingTime'] = current_time
                process['comebackTime'] = 0

        # Check if all processes have completed their burst time, reset them
        all_completed = all(process['remainingTime'] == 0 for process in processes)
        if all_completed:
            for process in processes:
                process['remainingTime'] = process['burstTime']

    calculate_times(processes)


def calculate_averages(processes):
    # Calculate total waiting time and total turnaround time
    total_waiting_time = sum(process['waitingTime'] - process['arrivalTime'] for process in processes)
    total_turnaround_time = sum(process['turnaroundTime'] - process['arrivalTime'] for process in processes)

    # Calculate average waiting time and average turnaround time
    avg_waiting_time = total_waiting_time / len(processes)
    avg_turnaround_time = total_turnaround_time / len(processes)

    return avg_waiting_time, avg_turnaround_time


def print_statistics(processes):
    # Print average waiting time and average turnaround time
    avg_waiting_time, avg_turnaround_time = calculate_averages(processes)
    print("Average Waiting Time: {:.3f}".format(avg_waiting_time))
    print("Average Turnaround Time: {:.3f}".format(avg_turnaround_time))


if __name__ == "__main__":
    # Define processes with their attributes
    processes = [
        {'processID': 1, 'arrivalTime': 0, 'burstTime': 10, 'remainingTime': 10, 'priority': 3,
         'waitingTime': 0, 'turnaroundTime': 0, 'comebackTime': 0},
        {'processID': 2, 'arrivalTime': 1, 'burstTime': 8, 'remainingTime': 8, 'priority': 2,
         'waitingTime': 0, 'turnaroundTime': 0, 'comebackTime': 0},
        {'processID': 3, 'arrivalTime': 3, 'burstTime': 14, 'remainingTime': 14, 'priority': 3,
         'waitingTime': 0, 'turnaroundTime': 0, 'comebackTime': 0},
        {'processID': 4, 'arrivalTime': 4, 'burstTime': 7, 'remainingTime': 7, 'priority': 1,
         'waitingTime': 0, 'turnaroundTime': 0, 'comebackTime': 0},
        {'processID': 5, 'arrivalTime': 6, 'burstTime': 5, 'remainingTime': 5, 'priority': 0,
         'waitingTime': 0, 'turnaroundTime': 0, 'comebackTime': 0},
        {'processID': 6, 'arrivalTime': 7, 'burstTime': 4, 'remainingTime': 4, 'priority': 1,
         'waitingTime': 0, 'turnaroundTime': 0, 'comebackTime': 0},
        {'processID': 7, 'arrivalTime': 8, 'burstTime': 6, 'remainingTime': 6, 'priority': 2,
         'waitingTime': 0, 'turnaroundTime': 0, 'comebackTime': 0}
    ]

    # Set the time limit for simulation
    time_limit = 200

    # Run the simulation and print results
    print("First Come First Served:")
    simulate_cpu(processes, time_limit)
    print_gantt_chart(processes)
    print_statistics(processes)
