def move_to_ready_queue(processes, ready_queue, current_time):
    # Move processes to the ready queue if they have arrived
    while processes and processes[0]['arrivalTime'] <= current_time:
        ready_queue.append(processes.pop(0))

def non_preemptive_priority_scheduling_with_aging(processes, aging_time):
    ready_queue = []
    waiting_queue = []
    gantt_chart = []
    current_time = 0
    total_waiting_time = 0
    total_turnaround_time = 0

    while processes or ready_queue or waiting_queue:
        move_to_ready_queue(processes, ready_queue, current_time)

        if ready_queue:
            # Select the process with the highest priority from the ready queue
            ready_queue.sort(key=lambda x: x['priority'], reverse=True)
            current_process = ready_queue.pop(0)

            # Calculate waiting time
            waiting_time = current_time - current_process['arrivalTime']
            total_waiting_time += waiting_time

            # Calculate turnaround time
            turnaround_time = waiting_time + current_process['burstTime']
            total_turnaround_time += turnaround_time

            # Append the current process to the Gantt chart
            gantt_chart.append((current_time, current_process['processID']))

            # Update the current time
            current_time += current_process['burstTime']

            # Move the process to the waiting queue
            waiting_queue.append(current_process)

            # Simulate aging by decrementing the priority of processes in the ready queue
            for process in ready_queue:
                process['priority'] -= 1
                if process['priority'] < 0:
                    process['priority'] = 0

        else:
            # If no process is ready, simulate idle time
            gantt_chart.append((current_time, -1))
            current_time += 1

    # Calculate averages
    num_processes = len(waiting_queue)
    avg_waiting_time = total_waiting_time / num_processes
    avg_turnaround_time = total_turnaround_time / num_processes

    return gantt_chart, avg_waiting_time, avg_turnaround_time

if __name__ == "__main__":
    # Define the processes with their arrival time, burst time, and priority
    processes = [
        {'processID': 1, 'arrivalTime': 0, 'burstTime': 10, 'priority': 3},
        {'processID': 2, 'arrivalTime': 14, 'burstTime': 4, 'priority': 2},
        {'processID': 3, 'arrivalTime': 19, 'burstTime': 5, 'priority': 4},
        {'processID': 4, 'arrivalTime': 25, 'burstTime': 6, 'priority': 1},
        {'processID': 5, 'arrivalTime': 29, 'burstTime': 4, 'priority': 5},
        {'processID': 6, 'arrivalTime': 34, 'burstTime': 5, 'priority': 2},
        {'processID': 7, 'arrivalTime': 40, 'burstTime': 6, 'priority': 3},
        {'processID': 8, 'arrivalTime': 94, 'burstTime': 5, 'priority': 4},
        {'processID': 9, 'arrivalTime': 100, 'burstTime': 6, 'priority': 2},
        {'processID': 10, 'arrivalTime': 104, 'burstTime': 4, 'priority': 1},
        {'processID': 11, 'arrivalTime': 109, 'burstTime': 5, 'priority': 3},
        {'processID': 12, 'arrivalTime': 115, 'burstTime': 6, 'priority': 4},
        {'processID': 13, 'arrivalTime': 149, 'burstTime': 5, 'priority': 5},
        {'processID': 14, 'arrivalTime': 154, 'burstTime': 6, 'priority': 3},
        {'processID': 15, 'arrivalTime': 160, 'burstTime': 4, 'priority': 2},
        {'processID': 16, 'arrivalTime': 164, 'burstTime': 5, 'priority': 4},
        {'processID': 17, 'arrivalTime': 169, 'burstTime': 6, 'priority': 1},
        {'processID': 18, 'arrivalTime': 175, 'burstTime': 4, 'priority': 5},
        {'processID': 19, 'arrivalTime': 179, 'burstTime': 6, 'priority': 3},
    ]

    # Call the scheduling function with the processes
    gantt_chart, avg_waiting_time, avg_turnaround_time = non_preemptive_priority_scheduling_with_aging(processes, aging_time=5)

    # Print Gantt chart
    print("Gantt Chart:")
    print("Start   |   Process")
    for start, process in gantt_chart:
        if process != -1:
            print(f"{start: <7}|   P{process}")
        else:
            print(f"{start: <7}|   Idle")

    # Print average waiting time and average turnaround time
    print("\nAverage Waiting Time:", avg_waiting_time)
    print("Average Turnaround Time:", avg_turnaround_time)

