def round_robin(processes, time_quantum, total_time):
    remaining_processes = list(processes)
    gantt_chart = []
    waiting_time = [0] * len(processes)
    turnaround_time = [0] * len(processes)
    current_time = 0

    while current_time <= total_time:
        for process in remaining_processes:
            if process['remainingTime'] > 0:
                if process['remainingTime'] <= time_quantum:
                    current_time += process['remainingTime']
                    process['remainingTime'] = 0
                else:
                    current_time += time_quantum
                    process['remainingTime'] -= time_quantum

                gantt_chart.append((process['processID'], current_time))

                # Check if the process is completed
                if process['remainingTime'] == 0:
                    turnaround_time[process['processID'] - 1] = current_time - process['arrivalTime']
                    waiting_time[process['processID'] - 1] = turnaround_time[process['processID'] - 1] - \
                                                               process['burstTime']

        # Move to the next time quantum
        current_time += 1

        # Remove completed processes
        remaining_processes = [process for process in remaining_processes if process['remainingTime'] > 0]

    return gantt_chart, waiting_time, turnaround_time


def print_gantt_chart(gantt_chart):
    print("Gantt Chart:")
    for i, (process_id, time) in enumerate(gantt_chart):
        if i > 0 and gantt_chart[i - 1][0] != process_id:
            print(f"P{process_id}")
        print(f"{time} ----", end=" ")

    print("\n\nAverage waiting time =", sum(waiting_time) / len(waiting_time))
    print("Average turnaround time =", sum(turnaround_time) / len(turnaround_time))


if __name__ == "__main__":
    processes = [
        {'processID': 1, 'arrivalTime': 0, 'burstTime': 10, 'remainingTime': 10},
        {'processID': 2, 'arrivalTime': 1, 'burstTime': 8, 'remainingTime': 8},
        {'processID': 3, 'arrivalTime': 3, 'burstTime': 14, 'remainingTime': 14},
        {'processID': 4, 'arrivalTime': 4, 'burstTime': 7, 'remainingTime': 7},
        {'processID': 5, 'arrivalTime': 6, 'burstTime': 5, 'remainingTime': 5},
        {'processID': 6, 'arrivalTime': 7, 'burstTime': 4, 'remainingTime': 4},
        {'processID': 7, 'arrivalTime': 8, 'burstTime': 6, 'remainingTime': 6},
    ]

    time_quantum = 5
    total_time = 200

    gantt_chart, waiting_time, turnaround_time = round_robin(processes, time_quantum, total_time)
    print_gantt_chart(gantt_chart)
def round_robin(processes, time_quantum, total_time):
    remaining_processes = list(processes)
    gantt_chart = []
    waiting_time = [0] * len(processes)
    turnaround_time = [0] * len(processes)
    current_time = 0

    while current_time <= total_time:
        for process in remaining_processes:
            if process['remainingTime'] > 0:
                if process['remainingTime'] <= time_quantum:
                    current_time += process['remainingTime']
                    process['remainingTime'] = 0
                else:
                    current_time += time_quantum
                    process['remainingTime'] -= time_quantum

                gantt_chart.append((process['processID'], current_time))

                # Check if the process is completed
                if process['remainingTime'] == 0:
                    turnaround_time[process['processID'] - 1] = current_time - process['arrivalTime']
                    waiting_time[process['processID'] - 1] = turnaround_time[process['processID'] - 1] - \
                                                               process['burstTime']

        # Move to the next time quantum
        current_time += 1

        # Remove completed processes
        remaining_processes = [process for process in remaining_processes if process['remainingTime'] > 0]

    return gantt_chart, waiting_time, turnaround_time


def print_gantt_chart(gantt_chart):
    print("Gantt Chart:")
    for i, (process_id, time) in enumerate(gantt_chart):
        if i > 0 and gantt_chart[i - 1][0] != process_id:
            print(f"P{process_id}")
        print(f"{time} ----", end=" ")

    print("\n\nAverage waiting time =", sum(waiting_time) / len(waiting_time))
    print("Average turnaround time =", sum(turnaround_time) / len(turnaround_time))


if __name__ == "__main__":
    processes = [
        {'processID': 1, 'arrivalTime': 0, 'burstTime': 10, 'remainingTime': 10},
        {'processID': 2, 'arrivalTime': 1, 'burstTime': 8, 'remainingTime': 8},
        {'processID': 3, 'arrivalTime': 3, 'burstTime': 14, 'remainingTime': 14},
        {'processID': 4, 'arrivalTime': 4, 'burstTime': 7, 'remainingTime': 7},
        {'processID': 5, 'arrivalTime': 6, 'burstTime': 5, 'remainingTime': 5},
        {'processID': 6, 'arrivalTime': 7, 'burstTime': 4, 'remainingTime': 4},
        {'processID': 7, 'arrivalTime': 8, 'burstTime': 6, 'remainingTime': 6},
    ]

    time_quantum = 5
    total_time = 200

    gantt_chart, waiting_time, turnaround_time = round_robin(processes, time_quantum, total_time)
    print_gantt_chart(gantt_chart)

