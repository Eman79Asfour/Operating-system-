from queue import PriorityQueue

class Process:
    def __init__(self, pid, priority, burst_time):
        self.pid = pid
        self.priority = priority
        self.burst_time = burst_time
        self.waiting_time = 0
        self.turnaround_time = 0

def preemptive_priority_scheduling_with_aging(processes, aging_time=5):
    ready_queue = PriorityQueue()
    waiting_queue = []

    gantt_chart = []
    total_waiting_time = 0
    total_turnaround_time = 0

    current_time = 0

    while current_time <= 200 or ready_queue.qsize() > 0 or waiting_queue:
        # Move processes to ready queue based on arrival time
        while processes and processes[0][0] <= current_time:
            pid, priority, burst_time = processes.pop(0)
            ready_queue.put((priority, Process(pid, priority, burst_time)))

        if ready_queue.qsize() == 0 and not waiting_queue:
            # If ready queue and waiting queue are empty, simulate idle time
            gantt_chart.append((current_time, -1))
            current_time += 1
            continue

        if ready_queue.qsize() == 0 and waiting_queue:
            # If ready queue is empty but waiting queue has processes, simulate idle time
            current_time += 1
            continue

        priority, current_process = ready_queue.get()

        # Update waiting time for processes in the ready queue
        for _, process in ready_queue.queue:
            process.waiting_time += 1

        # Execute process for one time unit
        gantt_chart.append((current_time, current_process.pid))
        current_process.burst_time -= 1

        # Move process to waiting queue if burst time is completed
        if current_process.burst_time == 0:
            current_process.turnaround_time = current_time + 1
            waiting_queue.append(current_process)
        else:
            ready_queue.put((priority, current_process))

        # Check if processes in waiting queue are ready to come back to the ready queue
        for process in list(waiting_queue):
            if current_time - process.turnaround_time >= aging_time:
                ready_queue.put((process.priority, process))
                waiting_queue.remove(process)

        current_time += 1

    # Calculate waiting time and turnaround time
    for process in waiting_queue:
        total_waiting_time += process.waiting_time
        total_turnaround_time += process.turnaround_time - process.waiting_time

    avg_waiting_time = total_waiting_time / len(waiting_queue)
    avg_turnaround_time = total_turnaround_time / len(waiting_queue)

    return gantt_chart, avg_waiting_time, avg_turnaround_time

iif __name__ == "__main__":
    # Example usage
    processes = [
        Process(process_id=1, arrival_time=0, burst_time=10, remaining_time=10),
        Process(process_id=2, arrival_time=1, burst_time=8, remaining_time=8),
        Process(process_id=3, arrival_time=3, burst_time=14, remaining_time=14),
        Process(process_id=4, arrival_time=4, burst_time=7, remaining_time=7),
        Process(process_id=5, arrival_time=6, burst_time=5, remaining_time=5),
        Process(process_id=6, arrival_time=7, burst_time=4, remaining_time=4),
        Process(process_id=7, arrival_time=8, burst_time=6, remaining_time=6),

    ]

    gantt_chart, avg_waiting_time, avg_turnaround_time = preemptive_priority_scheduling_with_aging(processes, aging_time=5)

    # Print Gantt chart
    print("Gantt Chart:")
    print("Start   |   Process")
    for start, process in gantt_chart:
        if process != -1:
            print(f"{start: <7}|   P{process}")
        else:
            print(f"{start: <7}|   Idle")

    # Print average waiting time and average turnaround time
    print("\nAverage Waiting Time:", avg_waiting_time)
    print("Average Turnaround Time:", avg_turnaround_time)
