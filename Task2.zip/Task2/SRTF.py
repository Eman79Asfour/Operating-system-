#Eman 1200206
#Shortest Remaining Time First.
def shortest_remaining_time(processes):
    current_time = 0
    remaining_processes = list(processes)
    gantt_chart = []
    waiting_time = [0] * len(processes)
    turnaround_time = [0] * len(processes)

    while remaining_processes:
        eligible_processes = [process for process in remaining_processes if process['arrivalTime'] <= current_time]
        
        if eligible_processes:
            # Select the process with the shortest remaining time
            current_process = min(eligible_processes, key=lambda x: x['remainingTime'])
            current_process['remainingTime'] -= 1

            # Record the Gantt Chart
            gantt_chart.append((current_process['processID'], current_time))

            # Check if the process is completed
            if current_process['remainingTime'] == 0:
                remaining_processes.remove(current_process)
                turnaround_time[current_process['processID'] - 1] = current_time + 1 - current_process['arrivalTime']
                waiting_time[current_process['processID'] - 1] = turnaround_time[current_process['processID'] - 1] - \
                                                                    current_process['burstTime']
        else:
            # If no eligible processes, move time forward
            gantt_chart.append((0, current_time))

        current_time += 1

    return gantt_chart, waiting_time, turnaround_time


def print_gantt_chart(gantt_chart):
    print("Gantt Chart:")
    for i, (process_id, time) in enumerate(gantt_chart):
        if i > 0 and gantt_chart[i - 1][0] != process_id:
            print(f"P{process_id}")
        print(f"{time} ----", end=" ")

    print("\n\nAverage waiting time =", sum(waiting_time) / len(waiting_time))
    print("Average turnaround time =", sum(turnaround_time) / len(turnaround_time))


if __name__ == "__main__":
    processes = [
        {'processID': 1, 'arrivalTime': 0, 'burstTime': 1, 'remainingTime': 1},
        {'processID': 2, 'arrivalTime': 9, 'burstTime': 8, 'remainingTime': 8},
        {'processID': 6, 'arrivalTime': 13, 'burstTime': 4, 'remainingTime': 4},
        {'processID': 5, 'arrivalTime': 18, 'burstTime': 5, 'remainingTime': 5},
        {'processID': 7, 'arrivalTime': 28, 'burstTime': 6, 'remainingTime': 6},
        {'processID': 6, 'arrivalTime': 66, 'burstTime': 4, 'remainingTime': 4},
        {'processID': 7, 'arrivalTime': 67, 'burstTime': 6, 'remainingTime': 6},
        {'processID': 6, 'arrivalTime': 71, 'burstTime': 4, 'remainingTime': 4},
        {'processID': 5, 'arrivalTime': 81, 'burstTime': 5, 'remainingTime': 5},
        {'processID': 7, 'arrivalTime': 119, 'burstTime': 6, 'remainingTime': 6},
        {'processID': 6, 'arrivalTime': 124, 'burstTime': 4, 'remainingTime': 4},
        {'processID': 5, 'arrivalTime': 129, 'burstTime': 5, 'remainingTime': 5},
        {'processID': 6, 'arrivalTime': 133, 'burstTime': 4, 'remainingTime': 4},
        {'processID': 5, 'arrivalTime': 138, 'burstTime': 5, 'remainingTime': 5},
        {'processID': 7, 'arrivalTime': 139, 'burstTime': 6, 'remainingTime': 6},
        {'processID': 6, 'arrivalTime': 149, 'burstTime': 4, 'remainingTime': 4},
        {'processID': 5, 'arrivalTime': 154, 'burstTime': 5, 'remainingTime': 5},
        {'processID': 7, 'arrivalTime': 160, 'burstTime': 6, 'remainingTime': 6},
        {'processID': 6, 'arrivalTime': 164, 'burstTime': 4, 'remainingTime': 4},
        {'processID': 5, 'arrivalTime': 169, 'burstTime': 5, 'remainingTime': 5},
        {'processID': 7, 'arrivalTime': 175, 'burstTime': 6, 'remainingTime': 6},
        {'processID': 6, 'arrivalTime': 179, 'burstTime': 4, 'remainingTime': 4},
    ]

    gantt_chart, waiting_time, turnaround_time = shortest_remaining_time(processes)
    print_gantt_chart(gantt_chart)
