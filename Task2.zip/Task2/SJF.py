# Eman 1200206
# Shortest Job First 
def calculate_times(processes):
    # Initialize variables
    current_time = 0

    # Initialize process data
    for process in processes:
        process['waitingTime'] = 0
        process['turnaroundTime'] = 0
        process['completionTime'] = 0
        process['remainingTime'] = process['burstTime']
        process['comebackTime'] = -1

    # Initialize current process and Gantt chart
    current_process = None
    gantt_chart = []

    # Process until all processes are completed
    while True:
        # If no current process, find eligible processes
        if current_process is None:
            eligible_processes = [p for p in processes if p['arrivalTime'] <= current_time and p['remainingTime'] > 0]
            if not eligible_processes:
                break

            # Select the process with the shortest remaining time
            current_process = min(eligible_processes, key=lambda x: x['remainingTime'])

            # Record the comeback time if it's the first time the process is selected
            if current_process['comebackTime'] < 0:
                current_process['comebackTime'] = current_time

        # Execute the current process
        current_process['remainingTime'] -= 1
        current_time += 1
        gantt_chart.append(current_process['processID'])

        # Check if the current process is completed
        if current_process['remainingTime'] == 0:
            current_process['completionTime'] = current_time
            current_process = None

    return gantt_chart, processes


def print_gantt_chart(gantt_chart, processes):
    print("Gantt Chart:")
    # Print Gantt chart with appropriate formatting
    for i, process_id in enumerate(gantt_chart):
        if i % 3 == 0:
            print(f"{i * 10} P{process_id}", end=" ")
        if (i + 1) % 5 == 0 and i > 0:
            print()

    # Print average waiting time and turnaround time
    print("\nAverage waiting time =", calculate_averages(processes)[0])
    print("Average turnaround time =", calculate_averages(processes)[1])


def calculate_averages(processes):
    # Calculate total waiting time and total turnaround time
    total_waiting_time = sum(p['completionTime'] - p['arrivalTime'] - p['burstTime'] for p in processes)
    total_turnaround_time = sum(p['completionTime'] - p['arrivalTime'] for p in processes)

    # Calculate average waiting time and average turnaround time
    avg_waiting_time = round(total_waiting_time / len(processes), 1)
    avg_turnaround_time = round(total_turnaround_time / len(processes), 1)

    return avg_waiting_time, avg_turnaround_time


if __name__ == "__main__":
    # Define the processes with their arrival time and burst time
    processes = [
        {'processID': 1, 'arrivalTime': 0, 'burstTime': 10},
        {'processID': 6, 'arrivalTime': 14, 'burstTime': 4},
        {'processID': 5, 'arrivalTime': 19, 'burstTime': 5},
        {'processID': 7, 'arrivalTime': 25, 'burstTime': 6},
        {'processID': 6, 'arrivalTime': 29, 'burstTime': 4},
        {'processID': 5, 'arrivalTime': 34, 'burstTime': 5},
        {'processID': 7, 'arrivalTime': 40, 'burstTime': 6},
        {'processID': 5, 'arrivalTime': 94, 'burstTime': 5},
        {'processID': 7, 'arrivalTime': 100, 'burstTime': 6},
        {'processID': 6, 'arrivalTime': 104, 'burstTime': 4},
        {'processID': 5, 'arrivalTime': 109, 'burstTime': 5},
        {'processID': 7, 'arrivalTime': 115, 'burstTime': 6},
        {'processID': 5, 'arrivalTime': 149, 'burstTime': 5},
        {'processID': 7, 'arrivalTime': 154, 'burstTime': 6},
        {'processID': 6, 'arrivalTime': 160, 'burstTime': 4},
        {'processID': 5, 'arrivalTime': 164, 'burstTime': 5},
        {'processID': 7, 'arrivalTime': 169, 'burstTime': 6},
        {'processID': 6, 'arrivalTime': 175, 'burstTime': 4},
        {'processID': 7, 'arrivalTime': 179, 'burstTime': 6},
    ]

    # Calculate and print Gantt Chart and statistics
    gantt_chart, processes = calculate_times(processes)
    print_gantt_chart(gantt_chart, processes)
